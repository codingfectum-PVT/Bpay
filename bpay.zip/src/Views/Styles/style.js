import styled from "@emotion/styled";

const PageWrapper = styled.div`
    min-height: 100vh;
    background-color: #F5F5F5;
`

export { PageWrapper }