# ReactThemeWithDayNight


This theme is including the following functionalities

1=> Mui Responsice menu

2=> Global color variables with Light/Dark

    to add the Color variables (/src/theme/index.js)

    to customize the Light/Dark Switch button (/src/Views/Components/LockerMenu/component)

3=> Redux

    to add the reducer you can find the store at (/src/Redux/store.js)

    to add the functions you can create file at (/src/Redux/)